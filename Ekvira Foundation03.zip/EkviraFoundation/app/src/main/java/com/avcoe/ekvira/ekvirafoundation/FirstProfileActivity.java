package com.avcoe.ekvira.ekvirafoundation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FirstProfileActivity extends AppCompatActivity {
    public String phoneNumber;
    Button createProfile;
    EditText firstNameText, lastNameText, emailText;
    Spinner gender;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_profile);

        //get bundle data
        Bundle bundle = getIntent().getExtras();
        phoneNumber = bundle.getString("phoneNumber");
        EditText editText = findViewById(R.id.phoneText);
        editText.setText(phoneNumber, TextView.BufferType.EDITABLE);

        firstNameText = findViewById(R.id.firstNameText);
        lastNameText = findViewById(R.id.lastNameText);
        emailText = findViewById(R.id.emailText);
        //phoneNumber get bu intent
        gender = findViewById(R.id.gender);
        createProfile = findViewById(R.id.createProfile);

        createProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //check not empty
                //...
                User user;
                user = new User();
                user.setFirstName(firstNameText.getText().toString());
                user.setLastName(lastNameText.getText().toString());
                user.setPhoneNumber(phoneNumber);
                user.setGender(gender.getSelectedItem().toString());
                user.setEmail(emailText.getText().toString());
                DatabaseReference reff = FirebaseDatabase.getInstance().getReference().child("User");
                reff.push().setValue(user);
                //new activity
                //Intent intent = new Intent(FirstProfileActivity.this,home.class);;
                //startActivity(intent);
            }
        });

    }
}
